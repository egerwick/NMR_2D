#ifndef __Edge_C
#define __Edge_C
#include "Edge.H"






#endif
