#ifndef __Similarity_ensemble_C
#define __Similarity_ensemble_C
#include "Similarity_ensemble.H"


Similarity_ensemble::Similarity_ensemble() {};
Similarity_ensemble::~Similarity_ensemble() {};



#endif
